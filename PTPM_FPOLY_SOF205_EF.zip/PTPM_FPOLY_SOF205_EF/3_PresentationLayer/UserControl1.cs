﻿using System;
using System.Windows.Forms;

namespace _3_PresentationLayer
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
    }
}
