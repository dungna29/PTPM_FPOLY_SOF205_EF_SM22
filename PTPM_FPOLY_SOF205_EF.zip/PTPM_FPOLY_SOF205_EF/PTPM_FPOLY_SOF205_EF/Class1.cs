﻿namespace PTPM_FPOLY_SOF205_EF
{
    public class Class1
    {
    }
}
