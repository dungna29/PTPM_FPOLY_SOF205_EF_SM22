﻿using System;

namespace _3_PresentationLayers
{
    public class Class1
    {
    }
}
